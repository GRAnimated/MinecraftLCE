#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_EnchantingButton_Normal {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
