#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_TextInput_Vita {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
