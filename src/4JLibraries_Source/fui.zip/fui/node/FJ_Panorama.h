#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Panorama {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
