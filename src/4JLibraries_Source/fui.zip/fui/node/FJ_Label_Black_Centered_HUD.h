#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_Black_Centered_HUD {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
