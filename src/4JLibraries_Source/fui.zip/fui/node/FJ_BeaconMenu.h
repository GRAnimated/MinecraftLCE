#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_BeaconMenu {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
