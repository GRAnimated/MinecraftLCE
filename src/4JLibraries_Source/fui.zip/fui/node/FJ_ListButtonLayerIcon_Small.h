#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_ListButtonLayerIcon_Small {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
