#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_SignEntryMenu {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
