#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_Blink_Normal {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
