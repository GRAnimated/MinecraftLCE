#pragma once

#include "fui/node/FJ_FuiNode.h"

class FJ_Document : public FJ_FuiNode {};
