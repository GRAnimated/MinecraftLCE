#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_Black_VerySmall_Centered {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
