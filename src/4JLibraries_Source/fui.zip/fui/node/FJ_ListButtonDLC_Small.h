#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_ListButtonDLC_Small {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
