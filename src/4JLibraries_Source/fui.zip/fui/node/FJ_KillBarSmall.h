#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_KillBarSmall {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
