#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_SlotList_Slot {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
