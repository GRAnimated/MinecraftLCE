#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_White_Centered {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
