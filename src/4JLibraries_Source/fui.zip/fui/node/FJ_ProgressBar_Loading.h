#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_ProgressBar_Loading {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
