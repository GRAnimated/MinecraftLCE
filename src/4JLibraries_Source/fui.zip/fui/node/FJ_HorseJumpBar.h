#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_HorseJumpBar {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
