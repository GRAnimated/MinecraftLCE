#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_KeyboardButtons_Keys_Small {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
