#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_PauseMenu {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
