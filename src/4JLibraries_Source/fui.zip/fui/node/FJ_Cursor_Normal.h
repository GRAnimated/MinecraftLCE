#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Cursor_Normal {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
