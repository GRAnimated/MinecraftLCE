#include "FJ_Button.h"

void FJ_Button::SetLabel(const std::wstring& label) {
    this->FJ_Base::SetLabel(label);
}
