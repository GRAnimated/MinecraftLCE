#pragma once

#include "fui/node/FJ_FuiNode.h"

class FJ_List_ListButton : public FJ_FuiNode {
public:
    static FJ_FuiNode* Create(fuiRenderNode*);
};
