#pragma once

class FJ_Checkbox {};
