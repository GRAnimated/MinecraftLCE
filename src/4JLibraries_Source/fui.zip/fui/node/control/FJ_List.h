#pragma once

#include "fui/node/FJ_FuiNode.h"

class FJ_List : public FJ_FuiNode {};
