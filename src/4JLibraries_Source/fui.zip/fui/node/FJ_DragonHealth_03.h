#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_DragonHealth_03 {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
