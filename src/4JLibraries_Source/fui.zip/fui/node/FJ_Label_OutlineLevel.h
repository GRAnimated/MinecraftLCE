#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_OutlineLevel {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
