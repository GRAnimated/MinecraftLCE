#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_SkinSelect_Small_Off {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
