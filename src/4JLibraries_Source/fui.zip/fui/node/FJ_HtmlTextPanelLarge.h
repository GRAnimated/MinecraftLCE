#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_HtmlTextPanelLarge {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
