#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_SmallBlack {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
