#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_EnchantingMenu {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
