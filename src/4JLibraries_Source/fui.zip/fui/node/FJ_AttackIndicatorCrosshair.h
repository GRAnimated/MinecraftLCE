#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_AttackIndicatorCrosshair {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
