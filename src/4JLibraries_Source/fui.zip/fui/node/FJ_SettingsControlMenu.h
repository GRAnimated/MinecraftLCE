#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_SettingsControlMenu {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
