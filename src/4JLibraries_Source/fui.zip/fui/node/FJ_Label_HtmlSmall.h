#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_HtmlSmall {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
