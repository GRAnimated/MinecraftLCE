#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_SocialPost {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
