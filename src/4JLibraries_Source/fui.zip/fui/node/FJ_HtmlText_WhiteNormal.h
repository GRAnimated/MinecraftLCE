#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_HtmlText_WhiteNormal {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
