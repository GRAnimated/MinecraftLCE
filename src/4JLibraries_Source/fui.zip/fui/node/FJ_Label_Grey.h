#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_Grey {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
