#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_Label_DragonHealth {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
