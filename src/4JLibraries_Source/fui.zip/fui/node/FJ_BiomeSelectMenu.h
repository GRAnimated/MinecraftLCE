#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_BiomeSelectMenu {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
