#pragma once

class FJ_FuiNode;
class fuiRenderNode;

// STUB CLASS
class FJ_ListLabel_SmallBlack {
public:
    static FJ_FuiNode* Create(fuiRenderNode *);
};
