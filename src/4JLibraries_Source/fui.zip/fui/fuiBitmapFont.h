#pragma once

#include "fui/fuiFontSet.h"

struct fuiBitmapFont : public fuiFontSet {};
