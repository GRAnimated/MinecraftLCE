#pragma once

#include "cstdint"

class FJ_FuiNode;
class FJ_EventListener {
public:
    uint32_t unk1;
    FJ_FuiNode* mTarget;
    uint64_t unk3;
};
